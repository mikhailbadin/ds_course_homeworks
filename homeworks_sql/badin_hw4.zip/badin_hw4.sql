SELECT ('ФИО: Бадин Михаил Львович');

-- Используя функцию определения размера таблицы, вывести top-5
-- самых больших таблиц базы (примечание у меня не прокатил стандартный вариант
-- поэтому использовал данные из pg_catalog.pg_tables а потом склеил
-- схему таблицы и имя для вычисления размера).
select tablename from pg_catalog.pg_tables
order by pg_relation_size('"'||schemaname||'"."'||tablename||'"') desc limit 5;


-- 1. Используя функцию array_agg собрать в массив все фильмы, просмотренные
-- пользователем. При этом повторов в списке контента быть не должно.
-- Назовём эту конструкцию ЗАПРОС1. Выборка должна содержать
-- два поля: userid и user_views
select userid, array_agg(distinct movieid) as user_views from ratings
group by userid limit 10;

-- 2. Создайте таблицу user_movies_agg, в которую сохраните результат запроса
drop table if exists user_movies_agg;
select userid, user_views INTO public.user_movies_agg FROM 
(select userid, array_agg(distinct movieid) as user_views from ratings
group by userid) as user_movies_agg_tmp;

-- 3. Используя следующий синтаксис, создайте функцию cross_arr оторая
-- принимает на вход два массива arr1 и arr2. Функция возвращает массив,
-- который представляет собой пересечение контента из обоих списков.
create or replace function cross_arr(arr1 bigint[], arr2 bigint[])
returns bigint[] as $ret$
declare
  ret bigint[];
begin
  select ARRAY(select * from unnest(arr1) intersect
  select * from unnest(arr2)) into ret;
  return ret;
end;
$ret$ LANGUAGE plpgsql;

-- 4. Сформируйте запрос следующего вида: достать из таблицы всевозможные наборы
-- u1, r1, u2, r2. u1 и u2 - это id пользователей r1 и r2 - соответствующие
-- массивы рейтингов
select agg1.userid as u1,
       agg1.user_views as ar1,
       agg2.userid as u2,
       agg2.user_views as ar2
from user_movies_agg as agg1, user_movies_agg as agg2
where agg1.userid != agg2.userid limit 10;

drop table if exists common_user_views;
with user_pairs as (
  select agg1.userid as u1,
       agg1.user_views as ar1,
       agg2.userid as u2,
       agg2.user_views as ar2
  from user_movies_agg as agg1 cross join user_movies_agg as agg2
  where agg1.userid != agg2.userid
) select u1, u2, cross_arr(ar1, ar2) as cross_arr into public.common_user_views
from user_pairs where array_length(cross_arr(ar1, ar2), 1) > 0 ;

-- Оставить как есть - это просто SELECT из таблички common_user_views для
-- контроля результата
select * from common_user_views limit 3;

-- Отсортируйте выборку из common_user_views по длине crossed_array и
-- оставите топ-10 пользователей с самыми большими пересечениями.
select u1, u2 from public.common_user_views
order by array_length(cross_arr, 1) desc limit 10;

-- Создайте по аналогии с cross_arr функцию diff_arr, которая вычитает 
-- один массив из другого.
create or replace function diff_arr(arr1 bigint[], arr2 bigint[])
returns bigint[] as $ret$
declare
  ret bigint[];
begin
  select ARRAY(select * from unnest(arr1) except
  select * from unnest(arr2)) into ret;
  return ret;
end;
$ret$ LANGUAGE plpgsql;

-- Сформируйте рекомендации - для каждой пары посоветуйте для u1 контент,
-- который видел u2, но не видел u1 (в виде массива).
-- Подсказка: нужно заджойнить user_movies_agg и common_user_views и применить
-- вашу функцию diff_arr к соответствующим полям.
-- с векторами фильмов
select t1.u1 as user1id,
       t1.u2 as user2id,
       diff_arr(t2.user_views, t1.cross_arr) as recs
from common_user_views as t1 join user_movies_agg as t2
on t1.u2 = t2.userid limit 10;
------------------------------------------------------------------------------------------------------------------
