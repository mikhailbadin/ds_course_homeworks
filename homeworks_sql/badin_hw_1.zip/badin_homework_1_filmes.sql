-- Create table filmes
create table filmes(
    title varchar(256) not null,
    id bigint primary key,
    country varchar(128),
    box_office bigint,
    release_year timestamp
);
-- Fill table filmes
insert into filmes values
    ('Человек паук', 1, 'США', 821708551, '2002-04-30'::timestamp),
    ('Железный человек', 2, 'США', 585174222, '2008-04-14'::timestamp),
    ('Мстители: Война бесконечности', 3, 'США', 2043538946, '2018-04-23'::timestamp),
    ('Трон: Наследие', 4, 'США', 400062763, '2010-11-30'::timestamp),
    ('Стражи Галактики. Часть 2', 5, 'США', 863756051, '2017-04-10'::timestamp);
-- Create table persons
create table persons(
    id bigint primary key,
    fio varchar(256)
);
-- Fill table persons
insert into persons values
    (1, 'Сем Рейми'),
    (2, 'Тоби Магуайр'),
    (3, 'Джон Фавро'),
    (4, 'Роберт Дауни мл.'),
    (5, 'Энтони Руссо'),
    (6, 'Джо Руссо'),
    (7, 'Крис Хемсворт'),
    (8, 'Джозеф Косински'),
    (9, 'Джефф Бриджес'),
    (10, 'Джеймс Ганн'),
    (11, 'Крис Пратт');
-- Create table persons2content
create table persons2content(
    person_id bigint not null,
    film_id bigint not null,
    person_type varchar(256)
);
-- Fill table persons2content
insert into persons2content values
    (1, 1, 'Режиссер'),
    (2, 1, 'Актер'),
    (3, 2, 'Режиссер'),
    (4, 2, 'Актер'),
    (4, 3, 'Актер'),
    (5, 3, 'Режиссер'),
    (6, 3, 'Режиссер'),
    (7, 3, 'Актер'),
    (8, 4, 'Режиссер'),
    (9, 4, 'Актер'),
    (10, 5, 'Режиссер'),
    (11, 3, 'Актер'),
    (11, 5, 'Актер');
