-- Create table oscar
create table oscar(
    film varchar(256),
    producer varchar(256),
    oscar boolean,
    imdb integer
);
--Fill table oscar
insert into oscar values
    ('Энни Холл', 'Вуди Аллен', true, 8),
    ('Быть Джоном Малковичем', 'Спайк Джонс', true, 7),
    ('Любовь и смерть', 'Вуди Аллен', false, 8);
-- Create table oscar2
create table oscar2(
    film varchar(256) ,
    oscar boolean,
    country varchar(128)
);
--Fill table oscar2
insert into oscar2 values
    ('Энни Холл', true, 'США'),
    ('Быть Джоном Малковичем', true, 'США'),
    ('Любовь и смерть', false, 'Россия');