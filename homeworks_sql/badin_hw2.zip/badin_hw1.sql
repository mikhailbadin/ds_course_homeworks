select ('ФИО: Бадин Михаил Львович');
-- 1.1 SELECT , LIMIT - выбрать 10 записей из таблицы rating
select * from public.ratings limit 10;

-- 1.2 WHERE, LIKE - выбрать из таблицы links всё записи, у которых imdbid
-- оканчивается на "42", а поле movieid между 100 и 1000
select * from public.links
where imdbid like '%42' and movieid > 100 and movieid < 1000 limit 10;

-- 2.1 INNER JOIN выбрать из таблицы links все imdb_id,
-- которым ставили рейтинг 5
select imdbid from public.links
join public.ratings on links.movieid = ratings.movieid
where rating = 5 limit 10;

-- 3.1 COUNT() Посчитать число фильмов без оценок
select count(*) as movies_without_rating from public.links
left join public.ratings on links.movieid = ratings.movieid
where ratings.movieid is null limit 10;

-- 3.2 GROUP BY, HAVING вывести top-10 пользователей,
-- у который средний рейтинг выше 3.5
select distinct userid, avg(rating) as avg_rating from public.ratings
group by userid having avg(rating) > 3.5 order by avg_rating desc limit 10;

-- 4.1 Подзапросы: достать 10 imbdId из links у которых средний рейтинг
-- больше 3.5. Нужно подсчитать средний рейтинг по все пользователям,
-- которые попали под условие - то есть в ответе должно быть одно число.
select imdbid, avg_rating from public.links join
(select movieid, avg(rating) as avg_rating from public.ratings
group by movieid having avg(rating) > 3.5 limit 10) as avg_ratings
on links.movieid = avg_ratings.movieid;

-- 4.2 Common Table Expressions: посчитать средний рейтинг по пользователям,
-- у которых более 10 оценок

with tmp_table as (select userid, rating from public.ratings
group by userid, rating having count(rating) > 10)
select avg(rating) as avg_rating from tmp_table;
